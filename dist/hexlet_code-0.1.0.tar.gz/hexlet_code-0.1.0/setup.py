# -*- coding: utf-8 -*-
from setuptools import setup

packages = \
['brain_games', 'brain_games.games', 'brain_games.scripts']

package_data = \
{'': ['*']}

install_requires = \
['prompt>=0.4.1,<0.5.0']

entry_points = \
{'console_scripts': ['brain-calc = brain_games.scripts.brain_calc:main',
                     'brain-even = brain_games.scripts.brain_even:main',
                     'brain-games = '
                     'brain_games.scripts.brain_games_script:main',
                     'brain-gcd = brain_games.scripts.brain_gcd:main',
                     'brain-prime = brain_games.scripts.brain_prime:main',
                     'brain-progression = '
                     'brain_games.scripts.brain_progression:main']}

setup_kwargs = {
    'name': 'hexlet-code',
    'version': '0.1.0',
    'description': "This is the first project 'Brain-games' from Hexlet's course of Python",
    'long_description': '# Brain-games\n\n### Hexlet tests and linter status:\n[![Actions Status](https://github.com/sergkim13/python-project-49/workflows/hexlet-check/badge.svg)](https://github.com/sergkim13/python-project-49/actions)\n[![Maintainability](https://api.codeclimate.com/v1/badges/b70296ec8ba01ee0e1ea/maintainability)](https://codeclimate.com/github/sergkim13/python-project-49/maintainability)\n\n### Description:\nWelcome to the Brain-games. There are five games you can play. Watch games demo in Demonstartion.\nMade by Kim Sergey as the first project in Hexlet course of Python.\n\n### Requirements:\n1. MacOS / Linux\n2. Poetry\n\n### Install: \n1. Make sure you have Poetry installed on your computer.\nIf you have not, type:\n`curl -sSL https://install.python-poetry.org | python3 -` (works for Linux, macOS, Windows (WSL))\n2. Clone repository:\n`$ git clone https://github.com/sergkim13/python-project-49.git`\n2. Type:\n `install brain-games`\n\n### Manual:\nTo play game type one of the list: \n1. `brain-even`\n2. `brain-calc`\n3. `brain-gcd`\n4. `brain-progression`\n5. `brain-prime`\n\n### Demonstraion\n\n[![asciicast](https://asciinema.org/a/UCoTZTHEWOlqcy0zrZVi9y4nr.svg)](https://asciinema.org/a/UCoTZTHEWOlqcy0zrZVi9y4nr)\n\n[![asciicast](https://asciinema.org/a/SP4FP9SSlvMbST9Fx8Wu4shcF.svg)](https://asciinema.org/a/SP4FP9SSlvMbST9Fx8Wu4shcF)\n\n[![asciicast](https://asciinema.org/a/VMczQUD95AVdqQwtO0kyUXBXu.svg)](https://asciinema.org/a/VMczQUD95AVdqQwtO0kyUXBXu)\n\n[![asciicast](https://asciinema.org/a/F70V3Xx11Nrw8ysUaxEnTBWiQ.svg)](https://asciinema.org/a/F70V3Xx11Nrw8ysUaxEnTBWiQ)\n\n[![asciicast](https://asciinema.org/a/8TyRlVTbZF1E8m0Z28lZXa4h2.svg)](https://asciinema.org/a/8TyRlVTbZF1E8m0Z28lZXa4h2)',
    'author': 'Sergey Kim',
    'author_email': '<sergkim7@gmail.com>',
    'maintainer': 'None',
    'maintainer_email': 'None',
    'url': 'https://github.com/sergkim13/python-project-49',
    'packages': packages,
    'package_data': package_data,
    'install_requires': install_requires,
    'entry_points': entry_points,
    'python_requires': '>=3.10,<4.0',
}


setup(**setup_kwargs)
