#!/usr/bin/env python3
from brain_games.games.calc import game_task, get_question
from brain_games.games.engine import *


def main():
    greeter()
    user_name = welcome_user()
    print_game_task()
    start_game()


if __name__ == '__main__':
    main()