import sys

from pprint import pprint

pprint(sys.path)