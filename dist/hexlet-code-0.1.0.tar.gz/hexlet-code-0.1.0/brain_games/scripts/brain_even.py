#!/usr/bin/env python3
from brain_games.even import even


def greeter():
    print('Welcome to the Brain Games!')


def main():
    greeter()
    even()


if __name__ == '__main__':
    main()
