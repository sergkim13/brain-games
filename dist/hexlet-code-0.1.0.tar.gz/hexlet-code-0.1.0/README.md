### Hexlet tests and linter status:
[![Actions Status](https://github.com/sergkim13/python-project-49/workflows/hexlet-check/badge.svg)](https://github.com/sergkim13/python-project-49/actions)
[![Maintainability](https://api.codeclimate.com/v1/badges/b70296ec8ba01ee0e1ea/maintainability)](https://codeclimate.com/github/sergkim13/python-project-49/maintainability)

https://asciinema.org/a/UCoTZTHEWOlqcy0zrZVi9y4nr
https://asciinema.org/a/SP4FP9SSlvMbST9Fx8Wu4shcF
https://asciinema.org/a/VMczQUD95AVdqQwtO0kyUXBXu
